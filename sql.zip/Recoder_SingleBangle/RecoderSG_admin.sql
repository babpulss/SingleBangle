-- �������� ���̺�
create table notice (
    seq number,
    title varchar2(100),
    contents varchar2(3000),
    writeDate timestamp
);

drop table notice;
delete from notice;
select * from notice;



-- �������� ������
create sequence notice_seq 
start with 1
increment by 1
nomaxvalue
nocache;

drop sequence notice_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- �湮��¥ ���̺�
CREATE TABLE visitCount
(
    seq             NUMBER    NOT NULL, 
    visittedDate    DATE      DEFAULT sysdate NULL, 
    CONSTRAINT VISITCOUNT_PK PRIMARY KEY (seq)
);

drop table visitCount;
delete from visitCount;
select * from visitCount;



-- �湮��¥ ������
CREATE SEQUENCE visitCount_SEQ
START WITH 1
INCREMENT BY 1
nomaxvalue
nocache;

drop sequence visitCount_SEQ;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- ��������Ʈ ���̺�
CREATE TABLE blackList
(
    seq          NUMBER            NOT NULL, 
    id           VARCHAR2(15)      NOT NULL, 
    addedDate    date              DEFAULT sysdate NULL, 
    reason       VARCHAR2(4000)    NULL, 
    blockTime    number            NULL, 
    CONSTRAINT BLACKLIST_PK PRIMARY KEY (seq)
);

drop table blackList;
delete from blackList;
select * from blackList;
ALTER TABLE blackList
    ADD CONSTRAINT FK_blackList_id_member_id FOREIGN KEY (id)
        REFERENCES member (id);



-- ��������Ʈ ������
CREATE SEQUENCE blacklist_seq
START WITH 1
INCREMENT BY 1
nomaxvalue
nocache;

drop sequence blacklist_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- �Խ��� �Ű� ���̺�
CREATE TABLE hasReported
(
    seq                 NUMBER            NOT NULL, 
    id                  VARCHAR2(15)      NOT NULL, 
    reportingDate       DATE              DEFAULT sysdate NOT NULL, 
    reason              VARCHAR2(4000)    NOT NULL, 
    reportedUrl         VARCHAR2(1000)    NOT NULL, 
    confirmReporting    VARCHAR2(1)       DEFAULT 'N' CHECK (confirmReporting IN ('Y', 'N')),
    confirmDate         DATE              DEFAULT sysdate NOT NULL, 
    CONSTRAINT HASREPORTED_PK PRIMARY KEY (seq)
);

drop table hasReported;
delete from hasReported;
select * from hasReported;



-- �Խ��� �Ű� ������
CREATE SEQUENCE hasReported_SEQ
START WITH 1
INCREMENT BY 1
nomaxvalue
nocache;

drop sequence hasReported_SEQ;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
select * from user_tables;
select * from user_sequences;
select * from user_constraints;