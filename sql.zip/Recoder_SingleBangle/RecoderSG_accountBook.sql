-- ����� ���̺�
CREATE TABLE account_book
(
    seq              NUMBER           NOT NULL, 
    id               VARCHAR2(12)     NOT NULL, 
    userName         VARCHAR2(15)     NOT NULL, 
    reportingDate    DATE             NOT NULL, 
    details          VARCHAR2(20)     NOT NULL, 
    payments         VARCHAR2(20)     NOT NULL, 
    spec             VARCHAR2(20)     NOT NULL, 
    income           NUMBER           NOT NULL, 
    expense          NUMBER           NOT NULL, 
    remarks          VARCHAR2(900)    NULL, 
    CONSTRAINT ACCOUNT_BOOK_PK PRIMARY KEY (seq)
);

drop table account_book;
delete from account_book;
select * from account_book;



-- ����� ������
CREATE SEQUENCE account_book_SEQ
START WITH 1
INCREMENT BY 1
NOMAXVALUE
NOCACHE;

drop sequence account_book_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
select * from user_tables;
select * from user_sequences;
select * from user_constraints;