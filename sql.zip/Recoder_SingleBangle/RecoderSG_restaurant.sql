-- ȥ��/ȥ�� ���̺�
create table restaurant(
    seq number constraint rst_pk primary key, 
    writer varchar2(12) not null,
    title varchar2(300) not null,
    placename varchar2(100) not null,
    jibunaddr varchar2(100) not null,
    roadaddr varchar2(100) not null,
    placephone varchar2(15) not null,
    placeurl varchar2(300) not null,
    xpos varchar2(50) not null,
    ypos varchar2(50) not null,
    writedate timestamp default sysdate not null,
    approvalCheck varchar2(1) default 'N' constraint approval_chk check (approvalCheck in ('Y', 'N'))
);

drop table restaurant;
delete from restaurant;
select * from restaurant;
update restaurant set approvalcheck = 'Y';



-- ȥ��/ȥ�� ������
create sequence restaurant_seq
start with 1
increment by 1
nominvalue
nomaxvalue
nocache;

drop sequence restaurant_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- ȥ��/ȥ�� ���� ���̺�
create table restaurantFile(
    seq number constraint rst_cnts_pk primary key,
    rootseq number not null,
    oriname varchar2(300) not null,
    sysname varchar2(300) not null,
    contents varchar2(4000)
);

drop table restaurantFile;
delete from restaurantFile;
select * from restaurantFile;



-- ȥ��/ȥ�� ���� ������
create sequence restaurant_file_seq
start with 1
increment by 1
nominvalue
nomaxvalue
nocache;

drop sequence restaurant_file_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
select * from user_tables;
select * from user_sequences;
select * from user_constraints;
--////////////////////////////////////////////////////////////////////



drop table sggcode;
select * from sggcode;
select * from sggcode where legalname not like '% %';