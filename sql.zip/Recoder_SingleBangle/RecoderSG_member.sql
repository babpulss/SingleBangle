-- ȸ�� ���̺�
create table member(
    id varchar2(15) constraint mem_pk primary key, 
    pw varchar2(128) not null,
    name varchar2(15) not null,
    gender varchar2(1) constraint gender_chk check (gender in ('M', 'F')),
    phone varchar2(11) not null,
    email varchar2(30) not null,
    postcode varchar2(5) not null,
    address1 varchar2(300) not null,
    address2 varchar2(300) not null,
    adminCheck varchar2(1) default 'N' constraint admin_chk check (adminCheck in ('Y', 'N')),
    blackCheck varchar2(1) default 'N' constraint black_chk check (blackCheck in ('Y', 'N'))
);

drop table member;
delete from member;
select * from member;
insert into member values('admin', 'rhksflwk1!', '������', 'M', '01012341234', 'admin123@recoder.com', '04540', '���� �߱� ���빮�� 120', '2��, 3��', 'N', 'N');
update member set adminCheck = 'Y' where id = 'admin';



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
select * from user_tables;
select * from user_sequences;
select * from user_constraints;
--////////////////////////////////////////////////////////////////////



drop table sggcode;
select * from sggcode;
select * from sggcode where legalname not like '% %';