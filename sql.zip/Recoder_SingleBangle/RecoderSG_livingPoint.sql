-- ��������Ʈ ���̺�
create table livingPoint(
    seq number primary key,
    category number not null,
    writer varchar2(15) not null,
    title varchar2(300) not null,
    contents varchar2(3000) not null,
    writeDate Timestamp default sysdate,
    viewCount number not null,
    scrapCount number not null,
    likeCount number not null
);

drop table livingPoint;
delete from livingPoint;
select * from livingPoint;



-- ��������Ʈ ������
create sequence livingpoint_seq
start with 1
increment by 1
nomaxvalue
nocache;

drop sequence livingPoint_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- ��������Ʈ ���� ���̺�
create table livingFile(
    seq number primary key,
    rootSeq number not null,
    fileName varchar2(300) not null,
    oriFileName varchar2(300) not null
);

drop table livingFile;
delete from livingFile;
select * from livingFile;



-- ��������Ʈ ���� ������
create sequence file_seq
start with 1
increment by 1
nomaxvalue
nocache;

drop sequence file_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- ��������Ʈ ��� ���̺�
create table livingComment(
seq number primary key,
rootSeq number not null,
writer varchar2(15) not null,
contents varchar2(600),
writeDate Timestamp default sysdate
);

drop table livingComment;
delete from livingComment;
select * from livingComment;



-- ��������Ʈ ��� ������
create sequence comment_seq
start with 1
increment by 1
nomaxvalue
nocache;

drop sequence comment_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- ��������Ʈ ��õ ���̺�
create table livingLike(
    seq number not null,
    id varchar2(20) not null
);

drop table livingLike;
delete from livingLike;
select * from livingLike;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- ��������Ʈ ��ũ�� ���̺�
create table livingScrap(
    seq number primary key,
    rootSeq number not null,
    category number not null,
    title varchar2(100) not null,
    id varchar2(12) not null,
    scrapDate Timestamp default sysdate
);

drop table livingScrap;
delete from livingScrap;
select * from livingScrap;



-- ��������Ʈ ��ũ�� ������
create sequence scrap_seq
start with 1
increment by 1
nomaxvalue
nocache;

drop sequence scrap_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
select * from user_tables;
select * from user_sequences;
select * from user_constraints;