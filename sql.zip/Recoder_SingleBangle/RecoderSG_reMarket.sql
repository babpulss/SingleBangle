-- re���� ���̺�
create table market(
    seq number primary key,
    title varchar(300),
    price number,
    content varchar(4000),
    writer varchar(50),
    category varchar(200),
    place varchar(300),
    writeDate timestamp,
    viewCount number,
    done varchar(2),
    gender varchar(3)
);

drop table market;
delete from market;
select * from market;



-- re���� ������
create sequence market_seq
start with 1
increment by 1
nomaxvalue
nocache;

drop sequence market_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- re���� ���� ���̺�
create table marketFile(
    SEQ number primary key,
    BOARD_SEQ number not null,
    ORI_NAME varchar(1000) not null,
    SYS_NAME varchar(1000) not null
);

drop table marketFile;
delete from marketFile;
select * from marketFile;



-- re���� ���� ������
create sequence marketFile_seq
start with 1
increment by 1
nomaxvalue
nocache;

drop sequence marketFile_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- re���� ��� ���̺�
create table marketReply(
    seq number primary key,
    recontent varchar(4000),
    writeDate timestamp,
    writer varchar(100),
    boardSeq number
);

drop table marketReply;
delete from marketReply;
select * from marketReply;



-- re���� ��� ������
create sequence marketReply_seq
start with 1
increment by 1
nomaxvalue
nocache;

drop sequence marketReply_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////



----------------------------------------------------------------------
-- ���� ���̺�
create table msgbox(
    seq number primary key,
    sender varchar(100) not null,
    RECEIVER varchar(100) not null,
    TITLE varchar(300) not null,
    CONTENTS varchar(4000) not null,
    read varchar(3)
);

drop table msgbox;
delete from msgbox;
select * from msgbox;



-- ���� ������
create sequence msgbox_seq
start with 1
increment by 1
nomaxvalue
nocache;

drop sequence msgbox_seq;



commit;
rollback;
--////////////////////////////////////////////////////////////////////

        

----------------------------------------------------------------------
select * from user_tables;
select * from user_sequences;
select * from user_constraints;